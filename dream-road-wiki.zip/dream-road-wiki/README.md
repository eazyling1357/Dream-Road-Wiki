# Dream Road Wiki

Информационный портал по Dream Road Online + **Backend API**.

## Быстрый старт

```bash
cd server
node index.js
```

Откройте http://localhost:3000

## Backend

- REST API на чистом Node.js (без npm-пакетов)
- JWT-авторизация, роли `admin` / `user`
- Пароли: scrypt
- Данные: `server/data/store.json`

| Метод | Путь | Доступ |
|--------|------|--------|
| GET | `/api/health` `/api/stats` `/api/cars` `/api/news` `/api/guides` | публичный |
| POST | `/api/auth/register` `/api/auth/login` | публичный |
| GET | `/api/auth/me` | авторизованный |
| CRUD | `/api/cars` `/news` `/guides` | admin |
| GET | `/api/users` | admin |

Админ: **admin** / **kassian89**

Подробнее: [server/README.md](server/README.md)

## Фронтенд

- Статические страницы (автомобили, новости, гайды, карта, FAQ)
- `/auth.html` — вход и регистрация
- `/admin/` — панель (только admin)
- `js/api.js` — клиент API
- RU/EN (`js/i18n.js`)

## Vercel

Импортируйте репозиторий → Framework **Other**.  
На Vercel Free работает **статика**; для полноценного API с сохранением данных нужен Node-хостинг (VPS, Railway, Render и т.п.).
