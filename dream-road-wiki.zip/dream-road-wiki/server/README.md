# Dream Road Wiki — Backend

Node.js HTTP-сервер без npm-зависимостей: статика + REST API + JWT-авторизация.

## Запуск

```bash
cd server
node index.js
# или
npm start
```

| URL | Описание |
|-----|----------|
| http://localhost:3000 | Сайт |
| /api/health | Health-check |
| /auth.html | Вход / регистрация |
| /admin/ | Админ-панель (role=admin) |

## Переменные окружения

| Переменная | По умолчанию | Описание |
|------------|--------------|----------|
| `PORT` | `3000` | Порт |
| `TOKEN_SECRET` | `drw-dev-secret-change-me` | Секрет JWT |
| `TOKEN_TTL_MS` | `28800000` (8 ч) | TTL токена |

## API

### Публичные
- `GET /api/health`
- `GET /api/stats`
- `GET /api/cars` · `GET /api/cars/:id`
- `GET /api/news` · `GET /api/news/:id`
- `GET /api/guides` · `GET /api/guides/:id`

### Авторизация
- `POST /api/auth/register` `{ username, password }`
- `POST /api/auth/login` `{ username, password }` → `{ token, user }`
- `GET /api/auth/me` — Bearer token

### Админ (Bearer + role=admin)
- `POST|PUT|DELETE /api/cars[/:id]`
- `POST|PUT|DELETE /api/news[/:id]`
- `POST|PUT|DELETE /api/guides[/:id]`
- `GET /api/users`

## Данные

`data/store.json` — users, cars, news, guides.

Админ по умолчанию: **admin** / **kassian89**

## Структура

```
server/
  index.js          # точка входа
  lib/store.js      # JSON store + нормализация
  lib/auth.js       # scrypt + JWT
  lib/http.js       # helpers, rate-limit, CORS
  data/store.json
```
