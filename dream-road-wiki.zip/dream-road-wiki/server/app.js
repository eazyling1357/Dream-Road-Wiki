/**
 * Dream Road Wiki — Backend API + static site
 * Node 18+, zero npm dependencies
 *
 *   node index.js
 *   PORT=3000 TOKEN_SECRET=secret node index.js
 */

'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const {
  readStore, writeStore, toSafeId, nextId,
  normalizeCar, normalizeNews, normalizeGuide,
} = require('./lib/store');
const {
  USERNAME_RE, hashPassword, verifyPassword, verifyToken,
  publicUser, issueToken,
} = require('./lib/auth');
const { json, readBody, getBearer, rateLimit, cors } = require('./lib/http');

const PORT = Number(process.env.PORT) || 3000;
const ROOT = path.join(__dirname, '..');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.map': 'application/json',
  '.txt': 'text/plain; charset=utf-8',
};

function requireUser(req, res) {
  const payload = verifyToken(getBearer(req));
  if (!payload) {
    json(res, 401, { error: 'Unauthorized' });
    return null;
  }
  return payload;
}

function requireAdmin(req, res) {
  const payload = requireUser(req, res);
  if (!payload) return null;
  if (payload.role !== 'admin') {
    json(res, 403, { error: 'Admin only' });
    return null;
  }
  return payload;
}

function safePath(urlPath) {
  const decoded = decodeURIComponent(urlPath.split('?')[0]);
  const normalized = path.normalize(decoded).replace(/^(\.\.[/\\])+/, '');
  const full = path.join(ROOT, normalized);
  if (!full.startsWith(ROOT)) return null;
  return full;
}

function serveStatic(req, res, urlPath) {
  let filePath = safePath(urlPath === '/' ? '/index.html' : urlPath);
  if (!filePath) {
    res.writeHead(403);
    return res.end('Forbidden');
  }
  if (fs.existsSync(filePath) && fs.statSync(filePath).isDirectory()) {
    filePath = path.join(filePath, 'index.html');
  }
  if (!fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end('Not found');
  }
  const ext = path.extname(filePath).toLowerCase();
  const headers = {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'X-Content-Type-Options': 'nosniff',
  };
  if (filePath.includes(path.sep + 'admin' + path.sep)) {
    headers['X-Robots-Tag'] = 'noindex, nofollow';
    headers['Cache-Control'] = 'no-store';
  }
  res.writeHead(200, headers);
  fs.createReadStream(filePath).pipe(res);
}

async function handleCrud(req, res, method, collection, normalize, id, label) {
  if (method === 'GET' && id == null) {
    return json(res, 200, readStore()[collection]);
  }
  if (method === 'GET' && id != null) {
    const item = readStore()[collection].find((x) => x.id === id);
    return item ? json(res, 200, item) : json(res, 404, { error: 'Not found' });
  }
  if (method === 'POST') {
    if (!requireAdmin(req, res)) return true;
    const body = await readBody(req);
    const store = readStore();
    const item = normalize(body, nextId(store[collection]));
    const bad = collection === 'cars' ? item.name === 'Без названия' : item.title === 'Без заголовка';
    if (bad) return json(res, 400, { error: label + ' required' });
    store[collection].push(item);
    writeStore(store);
    return json(res, 201, item);
  }
  if (method === 'PUT' && id != null) {
    if (!requireAdmin(req, res)) return true;
    const body = await readBody(req);
    const store = readStore();
    const idx = store[collection].findIndex((x) => x.id === id);
    if (idx < 0) return json(res, 404, { error: 'Not found' });
    const item = normalize(body, id);
    const bad = collection === 'cars' ? item.name === 'Без названия' : item.title === 'Без заголовка';
    if (bad) return json(res, 400, { error: label + ' required' });
    store[collection][idx] = item;
    writeStore(store);
    return json(res, 200, item);
  }
  if (method === 'DELETE' && id != null) {
    if (!requireAdmin(req, res)) return true;
    const store = readStore();
    const before = store[collection].length;
    store[collection] = store[collection].filter((x) => x.id !== id);
    if (store[collection].length === before) return json(res, 404, { error: 'Not found' });
    writeStore(store);
    res.writeHead(204);
    return res.end();
  }
  return null;
}

async function handleApi(req, res, pathname) {
  const method = req.method.toUpperCase();
  const parts = pathname.replace(/^\/api\/?/, '').split('/').filter(Boolean);
  const resource = parts[0] || '';
  const idPart = parts[1];
  const id = idPart ? toSafeId(idPart) : null;

  if (method === 'OPTIONS') {
    cors(res);
    res.writeHead(204, { 'Access-Control-Max-Age': '86400' });
    return res.end();
  }
  cors(res);

  try {
    if (resource === 'health' && method === 'GET') {
      return json(res, 200, {
        ok: true,
        service: 'dream-road-wiki-api',
        version: '1.1.0',
        time: new Date().toISOString(),
      });
    }

    // Register
    if (resource === 'auth' && parts[1] === 'register' && method === 'POST') {
      const ip = req.socket.remoteAddress || 'x';
      if (!rateLimit('reg:' + ip, 5, 60_000)) {
        return json(res, 429, { error: 'Too many requests' });
      }
      const body = await readBody(req);
      const username = String(body.username || '').trim();
      const password = String(body.password || '');
      if (!USERNAME_RE.test(username)) {
        return json(res, 400, { error: 'Логин: 3–32 символа (латиница, цифры, _)' });
      }
      if (password.length < 6 || password.length > 128) {
        return json(res, 400, { error: 'Пароль: от 6 до 128 символов' });
      }
      const store = readStore();
      if (store.users.some((u) => u.username.toLowerCase() === username.toLowerCase())) {
        return json(res, 409, { error: 'Такой логин уже занят' });
      }
      const user = {
        id: nextId(store.users),
        username,
        passwordHash: hashPassword(password),
        role: 'user',
        createdAt: new Date().toISOString(),
      };
      store.users.push(user);
      writeStore(store);
      return json(res, 201, issueToken(user));
    }

    // Login
    if (resource === 'auth' && parts[1] === 'login' && method === 'POST') {
      const ip = req.socket.remoteAddress || 'x';
      if (!rateLimit('login:' + ip, 10, 60_000)) {
        return json(res, 429, { error: 'Too many login attempts' });
      }
      const body = await readBody(req);
      const username = String(body.username || '').trim();
      const password = String(body.password || '');
      const store = readStore();
      const user = store.users.find((u) => u.username.toLowerCase() === username.toLowerCase());
      if (!user || !verifyPassword(password, user.passwordHash)) {
        return json(res, 401, { error: 'Неверный логин или пароль' });
      }
      return json(res, 200, issueToken(user));
    }

    // Me
    if (resource === 'auth' && parts[1] === 'me' && method === 'GET') {
      const auth = requireUser(req, res);
      if (!auth) return;
      const store = readStore();
      const user = store.users.find((u) => u.id === auth.uid || u.username === auth.sub);
      if (!user) return json(res, 401, { error: 'Unauthorized' });
      return json(res, 200, publicUser(user));
    }

    // Users list (admin)
    if (resource === 'users' && method === 'GET') {
      if (!requireAdmin(req, res)) return;
      const users = readStore().users.map(publicUser);
      return json(res, 200, users);
    }

    // Stats
    if (resource === 'stats' && method === 'GET') {
      const s = readStore();
      return json(res, 200, {
        cars: s.cars.length,
        news: s.news.length,
        guides: s.guides.length,
        freeCars: s.cars.filter((c) => c.price === 0).length,
        users: s.users.length,
      });
    }

    if (resource === 'cars') {
      const r = await handleCrud(req, res, method, 'cars', normalizeCar, id, 'Name');
      if (r !== null) return r;
    }
    if (resource === 'news') {
      const r = await handleCrud(req, res, method, 'news', normalizeNews, id, 'Title');
      if (r !== null) return r;
    }
    if (resource === 'guides') {
      const r = await handleCrud(req, res, method, 'guides', normalizeGuide, id, 'Title');
      if (r !== null) return r;
    }

    return json(res, 404, { error: 'Not found' });
  } catch (err) {
    console.error(err);
    if (err.message === 'Invalid JSON' || err.message === 'Body too large') {
      return json(res, 400, { error: err.message });
    }
    return json(res, 500, { error: 'Internal server error' });
  }
}

const server = http.createServer(async (req, res) => {
  const host = req.headers.host || ('localhost:' + PORT);
  const url = new URL(req.url || '/', 'http://' + host);
  if (url.pathname.startsWith('/api')) {
    return handleApi(req, res, url.pathname);
  }
  return serveStatic(req, res, url.pathname);
});

server.listen(PORT, () => {
  console.log('');
  console.log('  Dream Road Wiki Backend');
  console.log('  -----------------------');
  console.log('  Site   http://localhost:' + PORT);
  console.log('  API    http://localhost:' + PORT + '/api/health');
  console.log('  Auth   http://localhost:' + PORT + '/auth.html');
  console.log('  Admin  http://localhost:' + PORT + '/admin/');
  console.log('');
});
