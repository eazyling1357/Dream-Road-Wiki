/**
 * Dream Road Wiki — Admin Panel
 * Primary: REST API (/api). Fallback: localStorage if API unavailable.
 */

const ADMIN_KEY = 'drw_admin_auth';
const TOKEN_KEY = 'drw_api_token';
const CARS_KEY = 'drw_cars';
const NEWS_KEY = 'drw_news';
const GUIDES_KEY = 'drw_guides';
const LOGIN_ATTEMPTS_KEY = 'drw_login_attempts';

const ALLOWED_CATEGORIES = Object.freeze(['free', 'budget', 'premium', 'hyper']);
const SESSION_MAX_MS = 8 * 3600 * 1000;
const MAX_LOGIN_ATTEMPTS = 5;
const LOGIN_LOCK_MS = 60 * 1000;
const MAX_STRING_LEN = 2000;
const MAX_NAME_LEN = 120;

const DEMO_USER = 'admin';
const DEMO_PASS_LITERAL = 'kassian89';

/** API base: same origin when served by Node, or override */
const API_BASE = (typeof window !== 'undefined' && window.DRW_API_BASE) || '/api';

let apiAvailable = null; // null unknown, true/false

function escapeHtml(s) {
  if (s == null) return '';
  const d = document.createElement('div');
  d.textContent = String(s);
  return d.innerHTML;
}

function sanitizeString(s, maxLen) {
  maxLen = maxLen == null ? MAX_STRING_LEN : maxLen;
  if (typeof s !== 'string') s = s == null ? '' : String(s);
  s = s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '');
  return s.trim().slice(0, maxLen);
}

function sanitizeCategory(cat) {
  const c = String(cat || '').toLowerCase().trim();
  return ALLOWED_CATEGORIES.includes(c) ? c : 'budget';
}

function toSafeId(v) {
  const n = Number(v);
  if (!Number.isFinite(n) || n < 1 || n > Number.MAX_SAFE_INTEGER) return null;
  return Math.floor(n);
}

function toSafePrice(v) {
  const n = Number(v);
  if (!Number.isFinite(n) || n < 0) return 0;
  return Math.min(Math.floor(n), 1e12);
}

function safeJsonParse(raw, fallback) {
  try {
    if (raw == null || raw === '') return fallback;
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function isPlainObject(o) {
  return o !== null && typeof o === 'object' && !Array.isArray(o);
}

function normalizeCar(raw) {
  if (!isPlainObject(raw)) return null;
  const id = toSafeId(raw.id);
  if (id == null) return null;
  return {
    id: id,
    name: sanitizeString(raw.name, MAX_NAME_LEN) || 'Без названия',
    category: sanitizeCategory(raw.category),
    price: toSafePrice(raw.price),
    speed: sanitizeString(raw.speed, 80),
    accel: sanitizeString(raw.accel, 80),
    handling: sanitizeString(raw.handling, 80),
    desc: sanitizeString(raw.desc, 500),
  };
}

function normalizeNews(raw) {
  if (!isPlainObject(raw)) return null;
  const id = toSafeId(raw.id);
  if (id == null) return null;
  return {
    id: id,
    date: sanitizeString(raw.date, 80),
    title: sanitizeString(raw.title, MAX_NAME_LEN) || 'Без заголовка',
    body: sanitizeString(raw.body, MAX_STRING_LEN),
  };
}

function normalizeGuide(raw) {
  if (!isPlainObject(raw)) return null;
  const id = toSafeId(raw.id);
  if (id == null) return null;
  var icon = sanitizeString(raw.icon, 8);
  if (/[<>"'`]/.test(icon)) icon = '';
  return {
    id: id,
    icon: icon,
    title: sanitizeString(raw.title, MAX_NAME_LEN) || 'Без заголовка',
    body: sanitizeString(raw.body, MAX_STRING_LEN),
  };
}

function normalizeList(raw, normalizer) {
  if (!Array.isArray(raw)) return null;
  var out = [];
  for (var i = 0; i < raw.length; i++) {
    var n = normalizer(raw[i]);
    if (n) out.push(n);
  }
  return out;
}

function timingSafeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  var len = Math.max(a.length, b.length);
  var diff = a.length ^ b.length;
  for (var i = 0; i < len; i++) {
    diff |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
  }
  return diff === 0;
}

function getToken() {
  if (window.DRW_AUTH && DRW_AUTH.getToken()) return DRW_AUTH.getToken();
  return sessionStorage.getItem(TOKEN_KEY) || '';
}

function setToken(token) {
  if (token) sessionStorage.setItem(TOKEN_KEY, token);
  else sessionStorage.removeItem(TOKEN_KEY);
}

function authHeaders() {
  var t = getToken();
  var h = { 'Content-Type': 'application/json', Accept: 'application/json' };
  if (t) h.Authorization = 'Bearer ' + t;
  return h;
}

async function apiFetch(path, options) {
  options = options || {};
  var res = await fetch(API_BASE + path, Object.assign({}, options, {
    headers: Object.assign({}, authHeaders(), options.headers || {}),
  }));
  if (res.status === 204) return null;
  var data = null;
  var text = await res.text();
  if (text) {
    try { data = JSON.parse(text); } catch (e) { data = { raw: text }; }
  }
  if (!res.ok) {
    var err = new Error((data && data.error) || res.statusText || 'API error');
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}

async function checkApi() {
  try {
    await apiFetch('/health');
    apiAvailable = true;
  } catch (e) {
    apiAvailable = false;
  }
  return apiAvailable;
}

function getLoginLock() {
  var data = safeJsonParse(sessionStorage.getItem(LOGIN_ATTEMPTS_KEY), { n: 0, until: 0 });
  return { n: Number(data.n) || 0, until: Number(data.until) || 0 };
}

function setLoginLock(n, until) {
  sessionStorage.setItem(LOGIN_ATTEMPTS_KEY, JSON.stringify({ n: n, until: until }));
}

function simpleToken(user, ts) {
  var h = 0;
  var s = user + '|' + ts + '|drw';
  for (var i = 0; i < s.length; i++) h = ((h << 5) - h + s.charCodeAt(i)) | 0;
  return (h >>> 0).toString(16);
}

function isLoggedIn() {
  if (getToken()) return true;
  try {
    var raw = sessionStorage.getItem(ADMIN_KEY);
    if (!raw) return false;
    var data = JSON.parse(raw);
    if (!data || data.v !== 1 || data.user !== DEMO_USER) return false;
    if (typeof data.ts !== 'number' || data.ts > Date.now() + 60000) return false;
    if (data.ts < Date.now() - SESSION_MAX_MS) return false;
    if (data.t !== simpleToken(data.user, data.ts)) return false;
    return true;
  } catch (e) {
    return false;
  }
}

async function login(user, pass) {
  var lock = getLoginLock();
  if (lock.until > Date.now()) {
    return { ok: false, error: 'Слишком много попыток. Подождите минуту.' };
  }

  user = sanitizeString(user, 64);
  pass = typeof pass === 'string' ? pass : '';

  await checkApi();

  if (apiAvailable) {
    try {
      var result = await apiFetch('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ username: user, password: pass }),
      });
      setToken(result.token);
      setLoginLock(0, 0);
      sessionStorage.setItem(ADMIN_KEY, JSON.stringify({
        v: 1,
        user: result.user || user,
        ts: Date.now(),
        t: simpleToken(DEMO_USER, Date.now()),
        mode: 'api',
      }));
      return { ok: true, mode: 'api' };
    } catch (e) {
      if (e.status === 401) {
        var n = lock.n + 1;
        var until = n >= MAX_LOGIN_ATTEMPTS ? Date.now() + LOGIN_LOCK_MS : 0;
        setLoginLock(n >= MAX_LOGIN_ATTEMPTS ? 0 : n, until);
        return { ok: false, error: e.message || 'Неверный логин или пароль' };
      }
      // fall through to local demo if API error other than 401
    }
  }

  // Offline / local fallback
  var ok = user === DEMO_USER && timingSafeEqual(pass, DEMO_PASS_LITERAL);
  if (!ok) {
    var n2 = lock.n + 1;
    var until2 = n2 >= MAX_LOGIN_ATTEMPTS ? Date.now() + LOGIN_LOCK_MS : 0;
    setLoginLock(n2 >= MAX_LOGIN_ATTEMPTS ? 0 : n2, until2);
    return { ok: false, error: 'Неверный логин или пароль' };
  }
  setLoginLock(0, 0);
  setToken('');
  var ts = Date.now();
  sessionStorage.setItem(ADMIN_KEY, JSON.stringify({
    v: 1,
    user: DEMO_USER,
    ts: ts,
    t: simpleToken(DEMO_USER, ts),
    mode: 'local',
  }));
  return { ok: true, mode: 'local' };
}

function logout() {
  sessionStorage.removeItem(ADMIN_KEY);
  setToken('');
  window.location.href = '/auth.html';
}

function requireAuth() {
  // Prefer server JWT + admin role
  if (window.DRW_AUTH) {
    if (!DRW_AUTH.isLoggedIn()) {
      window.location.replace('/auth.html');
      return false;
    }
    if (!DRW_AUTH.isAdmin()) {
      alert('Доступ только для администратора');
      window.location.replace('/index.html');
      return false;
    }
    return true;
  }
  if (!isLoggedIn()) {
    window.location.replace('/auth.html');
    return false;
  }
  return true;
}

// ——— Data layer ———
function getDefaultCars() {
  return [
    { id: 1, name: 'Vortex G3', category: 'free', price: 0, speed: '', accel: '', handling: '', desc: 'Стартовый седан.' },
    { id: 2, name: 'Nova Sedan', category: 'free', price: 0, speed: '', accel: '', handling: '', desc: 'Бесплатный автомобиль для начала.' },
    { id: 3, name: 'Apex Camaro', category: 'budget', price: 40000, speed: '', accel: '', handling: '', desc: 'Надёжный седан.' },
    { id: 4, name: 'Striker C6', category: 'budget', price: 50000, speed: '', accel: '', handling: '', desc: 'Мощный седан.' },
    { id: 5, name: 'Pulse GT', category: 'budget', price: 50000, speed: '', accel: '', handling: '', desc: 'Хот-хэтч.' },
    { id: 6, name: 'Zenith Z', category: 'budget', price: 55000, speed: '', accel: '', handling: '', desc: 'Классический спорткар.' },
    { id: 7, name: 'Horizon E5', category: 'budget', price: 60000, speed: '', accel: '', handling: '', desc: 'Мощный седан.' },
    { id: 8, name: 'Horizon M4', category: 'budget', price: 70000, speed: '', accel: '', handling: '', desc: 'Спортивное купе.' },
    { id: 9, name: 'Liara L9', category: 'budget', price: 90000, speed: '', accel: '', handling: '', desc: 'Кроссовер.' },
    { id: 10, name: 'Aether IS', category: 'budget', price: 90000, speed: '', accel: '', handling: '', desc: 'Спортивный седан.' },
    { id: 11, name: 'Thunder SRT', category: 'budget', price: 90000, speed: '', accel: '', handling: '', desc: 'Маслкар.' },
    { id: 12, name: 'Striker W1', category: 'budget', price: 95000, speed: '', accel: '', handling: '', desc: 'Представительский седан.' },
    { id: 13, name: 'Striker S-Class', category: 'premium', price: 150000, speed: '', accel: '', handling: '', desc: 'Флагманский седан.' },
    { id: 14, name: 'Striker E63', category: 'premium', price: 150000, speed: '', accel: '', handling: '', desc: 'Спортивный седан.' },
    { id: 15, name: 'Horizon M5', category: 'premium', price: 150000, speed: '', accel: '', handling: '', desc: 'Популярный седан.' },
    { id: 16, name: 'Cascade 911', category: 'premium', price: 150000, speed: '', accel: '', handling: '', desc: 'Легендарное купе.' },
    { id: 17, name: 'Horizon M5 CS', category: 'premium', price: 155000, speed: '', accel: '', handling: '', desc: 'Облегчённая версия.' },
    { id: 18, name: 'Vortex RS7', category: 'premium', price: 160000, speed: '', accel: '', handling: '', desc: 'Спортивный фастбэк.' },
    { id: 19, name: 'Horizon M5 Ultra', category: 'premium', price: 200000, speed: '', accel: '', handling: '', desc: 'Топовая версия.' },
    { id: 20, name: 'Royal Dawn', category: 'hyper', price: 1000000, speed: '', accel: '', handling: '', desc: 'Роскошный кабриолет.' },
    { id: 21, name: 'Hyperion Chiron', category: 'hyper', price: 3000000, speed: '', accel: '', handling: '', desc: 'Гиперкар.' },
  ];
}

function getDefaultNews() {
  return [
    { id: 1, date: 'Октябрь 2026', title: 'Обновление 1.4.4', body: 'Настраиваемое управление, геймпад, фоторежим, улучшенный трафик.' },
    { id: 2, date: '2026', title: '10+ миллионов загрузок', body: 'Игра достигла значимого рубежа по скачиваниям.' },
  ];
}

function getDefaultGuides() {
  return [
    { id: 1, icon: '💰', title: 'Как быстро заработать', body: 'Участвуйте в заездах и активности в открытом мире.' },
    { id: 2, icon: '🛒', title: 'Покупка автомобилей', body: 'Авто покупаются в гараже/салоне.' },
    { id: 3, icon: '🔧', title: 'Тюнинг', body: 'Краска, диски, подвеска.' },
  ];
}

function localGetCars() {
  var list = normalizeList(safeJsonParse(localStorage.getItem(CARS_KEY), null), normalizeCar);
  return list && list.length ? list : getDefaultCars();
}
function localSaveCars(cars) {
  localStorage.setItem(CARS_KEY, JSON.stringify(normalizeList(cars, normalizeCar) || []));
}
function localGetNews() {
  var list = normalizeList(safeJsonParse(localStorage.getItem(NEWS_KEY), null), normalizeNews);
  return list && list.length ? list : getDefaultNews();
}
function localSaveNews(items) {
  localStorage.setItem(NEWS_KEY, JSON.stringify(normalizeList(items, normalizeNews) || []));
}
function localGetGuides() {
  var list = normalizeList(safeJsonParse(localStorage.getItem(GUIDES_KEY), null), normalizeGuide);
  return list && list.length ? list : getDefaultGuides();
}
function localSaveGuides(items) {
  localStorage.setItem(GUIDES_KEY, JSON.stringify(normalizeList(items, normalizeGuide) || []));
}

async function fetchCars() {
  if (apiAvailable) {
    try {
      var data = await apiFetch('/cars');
      var list = normalizeList(data, normalizeCar);
      if (list) return list;
    } catch (e) { /* fallback */ }
  }
  return localGetCars();
}

async function fetchNews() {
  if (apiAvailable) {
    try {
      var data = await apiFetch('/news');
      var list = normalizeList(data, normalizeNews);
      if (list) return list;
    } catch (e) { /* fallback */ }
  }
  return localGetNews();
}

async function fetchGuides() {
  if (apiAvailable) {
    try {
      var data = await apiFetch('/guides');
      var list = normalizeList(data, normalizeGuide);
      if (list) return list;
    } catch (e) { /* fallback */ }
  }
  return localGetGuides();
}

function nextId(items) {
  var max = 0;
  for (var i = 0; i < items.length; i++) {
    var id = toSafeId(items[i].id);
    if (id != null && id > max) max = id;
  }
  return max + 1;
}

function formatPrice(n) {
  var p = toSafePrice(n);
  if (p === 0) return '$0 (бесплатно)';
  return '$' + p.toLocaleString('ru-RU');
}

function categoryBadge(cat) {
  var c = sanitizeCategory(cat);
  var map = { free: 'badge-free', budget: 'badge-budget', premium: 'badge-premium', hyper: 'badge-hyper' };
  var labels = { free: 'Бесплатно', budget: 'До 100k', premium: 'Премиум', hyper: 'Гиперкар' };
  return '<span class="badge ' + map[c] + '">' + labels[c] + '</span>';
}

function toast(msg, type) {
  type = type || 'success';
  var el = document.querySelector('.toast');
  if (!el) {
    el = document.createElement('div');
    el.className = 'toast';
    document.body.appendChild(el);
  }
  el.textContent = String(msg);
  el.className = 'toast ' + (type === 'error' ? 'error' : 'success') + ' show';
  setTimeout(function () { el.classList.remove('show'); }, 2500);
}

function setApiBadge() {
  var el = document.getElementById('api-status');
  if (!el) return;
  if (apiAvailable === true) {
    el.textContent = 'API: online';
    el.style.color = 'var(--accent-green, #00c853)';
  } else if (apiAvailable === false) {
    el.textContent = 'API: offline (localStorage)';
    el.style.color = 'var(--accent-orange, #f77f00)';
  } else {
    el.textContent = 'API: …';
  }
}

function initLogin() {
  if (isLoggedIn()) {
    window.location.replace('/admin/dashboard.html');
    return;
  }
  var form = document.getElementById('login-form');
  var err = document.getElementById('login-error');
  if (!form) return;

  form.addEventListener('submit', async function (e) {
    e.preventDefault();
    err.classList.remove('show');
    var user = form.username.value;
    var pass = form.password.value;
    var btn = form.querySelector('button[type="submit"]');
    if (btn) btn.disabled = true;
    try {
      var result = await login(user, pass);
      if (result.ok) {
        window.location.replace('/admin/dashboard.html');
      } else {
        err.textContent = result.error || 'Ошибка входа';
        err.classList.add('show');
      }
    } finally {
      if (btn) btn.disabled = false;
    }
  });
}

async function initDashboard() {
  if (!requireAuth()) return;
  await checkApi();
  setApiBadge();

  var mobileBtn = document.querySelector('.mobile-menu-btn');
  var sidebar = document.querySelector('.sidebar');
  if (mobileBtn && sidebar) {
    mobileBtn.addEventListener('click', function () { sidebar.classList.toggle('open'); });
  }

  document.querySelectorAll('[data-logout]').forEach(function (btn) {
    btn.addEventListener('click', logout);
  });

  var page = document.body.dataset.page || 'overview';
  if (page === 'overview') await renderOverview();
  if (page === 'cars') await renderCarsAdmin();
  if (page === 'news') await renderNewsAdmin();
  if (page === 'guides') await renderGuidesAdmin();
}

async function renderOverview() {
  var cars = await fetchCars();
  var news = await fetchNews();
  var guides = await fetchGuides();
  var el = document.getElementById('stats');
  if (!el) return;
  el.innerHTML =
    '<div class="stat-card"><div class="value">' + cars.length + '</div><div class="label">Автомобилей</div></div>' +
    '<div class="stat-card"><div class="value">' + news.length + '</div><div class="label">Новостей</div></div>' +
    '<div class="stat-card"><div class="value">' + guides.length + '</div><div class="label">Гайдов</div></div>' +
    '<div class="stat-card"><div class="value">' + cars.filter(function (c) { return c.price === 0; }).length + '</div><div class="label">Бесплатных авто</div></div>';
}

async function renderCarsAdmin() {
  var cars = await fetchCars();
  var tbody = document.querySelector('#cars-table tbody');
  if (!tbody) return;
  tbody.innerHTML = cars.map(function (c) {
    return '<tr>' +
      '<td>' + c.id + '</td>' +
      '<td><strong>' + escapeHtml(c.name) + '</strong></td>' +
      '<td>' + categoryBadge(c.category) + '</td>' +
      '<td>' + escapeHtml(formatPrice(c.price)) + '</td>' +
      '<td class="actions">' +
        '<button type="button" class="btn btn-sm btn-secondary" data-edit-car="' + c.id + '">Изменить</button> ' +
        '<button type="button" class="btn btn-sm btn-danger" data-del-car="' + c.id + '">Удалить</button>' +
      '</td></tr>';
  }).join('');

  tbody.querySelectorAll('[data-edit-car]').forEach(function (btn) {
    btn.addEventListener('click', function () { openCarModal(toSafeId(btn.dataset.editCar)); });
  });
  tbody.querySelectorAll('[data-del-car]').forEach(function (btn) {
    btn.addEventListener('click', async function () {
      var delId = toSafeId(btn.dataset.delCar);
      if (delId == null) return;
      if (!confirm('Удалить автомобиль?')) return;
      try {
        if (apiAvailable && getToken()) {
          await apiFetch('/cars/' + delId, { method: 'DELETE' });
        } else {
          localSaveCars(localGetCars().filter(function (c) { return c.id !== delId; }));
        }
        toast('Автомобиль удалён');
        await renderCarsAdmin();
      } catch (e) {
        toast(e.message || 'Ошибка удаления', 'error');
      }
    });
  });
}

async function openCarModal(id) {
  var cars = await fetchCars();
  var car = id ? cars.find(function (c) { return c.id === id; }) : null;
  var modal = document.getElementById('car-modal');
  var form = document.getElementById('car-form');
  if (!modal || !form) return;
  form.reset();
  form.dataset.id = id ? String(id) : '';
  document.getElementById('car-modal-title').textContent = car ? 'Редактировать авто' : 'Добавить авто';
  if (car) {
    form.name.value = car.name;
    form.category.value = sanitizeCategory(car.category);
    form.price.value = car.price;
    form.speed.value = car.speed || '';
    form.accel.value = car.accel || '';
    form.handling.value = car.handling || '';
    form.desc.value = car.desc || '';
  }
  modal.classList.add('open');
}

function closeCarModal() {
  var m = document.getElementById('car-modal');
  if (m) m.classList.remove('open');
}

async function saveCarForm(e) {
  e.preventDefault();
  var form = e.target;
  var id = form.dataset.id ? toSafeId(form.dataset.id) : null;
  var payload = {
    name: form.name.value,
    category: form.category.value,
    price: form.price.value,
    speed: form.speed.value,
    accel: form.accel.value,
    handling: form.handling.value,
    desc: form.desc.value,
  };
  try {
    if (apiAvailable && getToken()) {
      if (id) await apiFetch('/cars/' + id, { method: 'PUT', body: JSON.stringify(payload) });
      else await apiFetch('/cars', { method: 'POST', body: JSON.stringify(payload) });
    } else {
      var cars = localGetCars();
      var data = normalizeCar(Object.assign({ id: id || nextId(cars) }, payload));
      if (!data || data.name === 'Без названия') { toast('Укажите название', 'error'); return; }
      if (id) {
        var i = cars.findIndex(function (c) { return c.id === id; });
        if (i >= 0) cars[i] = data; else cars.push(data);
      } else cars.push(data);
      localSaveCars(cars);
    }
    closeCarModal();
    toast(id ? 'Сохранено' : 'Автомобиль добавлен');
    await renderCarsAdmin();
  } catch (err) {
    toast(err.message || 'Ошибка сохранения', 'error');
  }
}

async function renderNewsAdmin() {
  var items = await fetchNews();
  var tbody = document.querySelector('#news-table tbody');
  if (!tbody) return;
  tbody.innerHTML = items.map(function (n) {
    return '<tr>' +
      '<td>' + n.id + '</td>' +
      '<td>' + escapeHtml(n.date) + '</td>' +
      '<td><strong>' + escapeHtml(n.title) + '</strong></td>' +
      '<td class="actions">' +
        '<button type="button" class="btn btn-sm btn-secondary" data-edit-news="' + n.id + '">Изменить</button> ' +
        '<button type="button" class="btn btn-sm btn-danger" data-del-news="' + n.id + '">Удалить</button>' +
      '</td></tr>';
  }).join('');

  tbody.querySelectorAll('[data-edit-news]').forEach(function (btn) {
    btn.addEventListener('click', function () { openNewsModal(toSafeId(btn.dataset.editNews)); });
  });
  tbody.querySelectorAll('[data-del-news]').forEach(function (btn) {
    btn.addEventListener('click', async function () {
      var delId = toSafeId(btn.dataset.delNews);
      if (delId == null) return;
      if (!confirm('Удалить новость?')) return;
      try {
        if (apiAvailable && getToken()) await apiFetch('/news/' + delId, { method: 'DELETE' });
        else localSaveNews(localGetNews().filter(function (n) { return n.id !== delId; }));
        toast('Новость удалена');
        await renderNewsAdmin();
      } catch (e) {
        toast(e.message || 'Ошибка', 'error');
      }
    });
  });
}

async function openNewsModal(id) {
  var items = await fetchNews();
  var item = id ? items.find(function (n) { return n.id === id; }) : null;
  var modal = document.getElementById('news-modal');
  var form = document.getElementById('news-form');
  if (!modal || !form) return;
  form.reset();
  form.dataset.id = id ? String(id) : '';
  document.getElementById('news-modal-title').textContent = item ? 'Редактировать новость' : 'Добавить новость';
  if (item) {
    form.date.value = item.date;
    form.title.value = item.title;
    form.body.value = item.body;
  }
  modal.classList.add('open');
}

function closeNewsModal() {
  var m = document.getElementById('news-modal');
  if (m) m.classList.remove('open');
}

async function saveNewsForm(e) {
  e.preventDefault();
  var form = e.target;
  var id = form.dataset.id ? toSafeId(form.dataset.id) : null;
  var payload = { date: form.date.value, title: form.title.value, body: form.body.value };
  try {
    if (apiAvailable && getToken()) {
      if (id) await apiFetch('/news/' + id, { method: 'PUT', body: JSON.stringify(payload) });
      else await apiFetch('/news', { method: 'POST', body: JSON.stringify(payload) });
    } else {
      var items = localGetNews();
      var data = normalizeNews(Object.assign({ id: id || nextId(items) }, payload));
      if (!data || data.title === 'Без заголовка') { toast('Укажите заголовок', 'error'); return; }
      if (id) {
        var i = items.findIndex(function (n) { return n.id === id; });
        if (i >= 0) items[i] = data; else items.push(data);
      } else items.push(data);
      localSaveNews(items);
    }
    closeNewsModal();
    toast(id ? 'Сохранено' : 'Новость добавлена');
    await renderNewsAdmin();
  } catch (err) {
    toast(err.message || 'Ошибка', 'error');
  }
}

async function renderGuidesAdmin() {
  var items = await fetchGuides();
  var tbody = document.querySelector('#guides-table tbody');
  if (!tbody) return;
  tbody.innerHTML = items.map(function (g) {
    return '<tr>' +
      '<td>' + g.id + '</td>' +
      '<td>' + escapeHtml(g.icon || '') + '</td>' +
      '<td><strong>' + escapeHtml(g.title) + '</strong></td>' +
      '<td class="actions">' +
        '<button type="button" class="btn btn-sm btn-secondary" data-edit-guide="' + g.id + '">Изменить</button> ' +
        '<button type="button" class="btn btn-sm btn-danger" data-del-guide="' + g.id + '">Удалить</button>' +
      '</td></tr>';
  }).join('');

  tbody.querySelectorAll('[data-edit-guide]').forEach(function (btn) {
    btn.addEventListener('click', function () { openGuideModal(toSafeId(btn.dataset.editGuide)); });
  });
  tbody.querySelectorAll('[data-del-guide]').forEach(function (btn) {
    btn.addEventListener('click', async function () {
      var delId = toSafeId(btn.dataset.delGuide);
      if (delId == null) return;
      if (!confirm('Удалить гайд?')) return;
      try {
        if (apiAvailable && getToken()) await apiFetch('/guides/' + delId, { method: 'DELETE' });
        else localSaveGuides(localGetGuides().filter(function (g) { return g.id !== delId; }));
        toast('Гайд удалён');
        await renderGuidesAdmin();
      } catch (e) {
        toast(e.message || 'Ошибка', 'error');
      }
    });
  });
}

async function openGuideModal(id) {
  var items = await fetchGuides();
  var item = id ? items.find(function (g) { return g.id === id; }) : null;
  var modal = document.getElementById('guide-modal');
  var form = document.getElementById('guide-form');
  if (!modal || !form) return;
  form.reset();
  form.dataset.id = id ? String(id) : '';
  document.getElementById('guide-modal-title').textContent = item ? 'Редактировать гайд' : 'Добавить гайд';
  if (item) {
    form.icon.value = item.icon || '';
    form.title.value = item.title;
    form.body.value = item.body;
  }
  modal.classList.add('open');
}

function closeGuideModal() {
  var m = document.getElementById('guide-modal');
  if (m) m.classList.remove('open');
}

async function saveGuideForm(e) {
  e.preventDefault();
  var form = e.target;
  var id = form.dataset.id ? toSafeId(form.dataset.id) : null;
  var payload = { icon: form.icon.value, title: form.title.value, body: form.body.value };
  try {
    if (apiAvailable && getToken()) {
      if (id) await apiFetch('/guides/' + id, { method: 'PUT', body: JSON.stringify(payload) });
      else await apiFetch('/guides', { method: 'POST', body: JSON.stringify(payload) });
    } else {
      var items = localGetGuides();
      var data = normalizeGuide(Object.assign({ id: id || nextId(items) }, payload));
      if (!data || data.title === 'Без заголовка') { toast('Укажите заголовок', 'error'); return; }
      if (id) {
        var i = items.findIndex(function (g) { return g.id === id; });
        if (i >= 0) items[i] = data; else items.push(data);
      } else items.push(data);
      localSaveGuides(items);
    }
    closeGuideModal();
    toast(id ? 'Сохранено' : 'Гайд добавлен');
    await renderGuidesAdmin();
  } catch (err) {
    toast(err.message || 'Ошибка', 'error');
  }
}

function resetAllData() {
  if (!confirm('Сбросить локальный кэш (localStorage)? Данные API не удаляются.')) return;
  localStorage.removeItem(CARS_KEY);
  localStorage.removeItem(NEWS_KEY);
  localStorage.removeItem(GUIDES_KEY);
  toast('Локальный кэш сброшен');
  location.reload();
}

document.addEventListener('DOMContentLoaded', function () {
  if (document.body.classList.contains('login-page')) initLogin();
  else if (document.body.classList.contains('admin-page')) initDashboard();
});

window.openCarModal = openCarModal;
window.closeCarModal = closeCarModal;
window.saveCarForm = saveCarForm;
window.openNewsModal = openNewsModal;
window.closeNewsModal = closeNewsModal;
window.saveNewsForm = saveNewsForm;
window.openGuideModal = openGuideModal;
window.closeGuideModal = closeGuideModal;
window.saveGuideForm = saveGuideForm;
window.resetAllData = resetAllData;
