/**
 * Auth client: login / register via API
 */
(function () {
  const TOKEN_KEY = 'drw_api_token';
  const USER_KEY = 'drw_user';
  const API_BASE = window.DRW_API_BASE || '/api';

  function getToken() {
    return sessionStorage.getItem(TOKEN_KEY) || '';
  }
  function setSession(token, user) {
    if (token) sessionStorage.setItem(TOKEN_KEY, token);
    else sessionStorage.removeItem(TOKEN_KEY);
    if (user) sessionStorage.setItem(USER_KEY, JSON.stringify(user));
    else sessionStorage.removeItem(USER_KEY);
  }
  function getUser() {
    try {
      return JSON.parse(sessionStorage.getItem(USER_KEY) || 'null');
    } catch {
      return null;
    }
  }
  function isLoggedIn() {
    return !!getToken() && !!getUser();
  }
  function isAdmin() {
    const u = getUser();
    return !!(u && u.role === 'admin');
  }

  async function api(path, options) {
    options = options || {};
    const headers = Object.assign(
      { Accept: 'application/json', 'Content-Type': 'application/json' },
      options.headers || {}
    );
    const t = getToken();
    if (t) headers.Authorization = 'Bearer ' + t;
    const res = await fetch(API_BASE + path, Object.assign({}, options, { headers }));
    const text = await res.text();
    let data = null;
    if (text) {
      try {
        data = JSON.parse(text);
      } catch {
        data = { raw: text };
      }
    }
    if (!res.ok) {
      const err = new Error((data && data.error) || res.statusText || 'Error');
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  async function login(username, password) {
    const data = await api('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });
    setSession(data.token, data.user);
    return data;
  }

  async function register(username, password) {
    const data = await api('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });
    setSession(data.token, data.user);
    return data;
  }

  function logout() {
    setSession('', null);
    window.location.href = '/auth.html';
  }

  function redirectAfterAuth(user) {
    if (user && user.role === 'admin') {
      window.location.href = '/admin/dashboard.html';
    } else {
      window.location.href = '/index.html';
    }
  }

  // Auth page UI
  document.addEventListener('DOMContentLoaded', () => {
    if (isLoggedIn() && location.pathname.includes('auth')) {
      redirectAfterAuth(getUser());
      return;
    }

    document.querySelectorAll('[data-tab]').forEach((btn) => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('[data-tab]').forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
        document.querySelectorAll('.auth-panel').forEach((p) => p.classList.remove('active'));
        const panel = document.getElementById('panel-' + btn.getAttribute('data-tab'));
        if (panel) panel.classList.add('active');
      });
    });

    const err = document.getElementById('auth-error');
    const ok = document.getElementById('auth-ok');
    function showErr(msg) {
      if (ok) ok.style.display = 'none';
      if (!err) return;
      err.textContent = msg;
      err.classList.add('show');
      err.style.display = 'block';
    }
    function showOk(msg) {
      if (err) {
        err.classList.remove('show');
        err.style.display = 'none';
      }
      if (!ok) return;
      ok.textContent = msg;
      ok.style.display = 'block';
    }

    const loginForm = document.getElementById('login-form');
    if (loginForm) {
      loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = loginForm.querySelector('button[type="submit"]');
        if (btn) btn.disabled = true;
        try {
          const data = await login(loginForm.username.value.trim(), loginForm.password.value);
          redirectAfterAuth(data.user);
        } catch (ex) {
          showErr(ex.message || 'Error');
        } finally {
          if (btn) btn.disabled = false;
        }
      });
    }

    const regForm = document.getElementById('register-form');
    if (regForm) {
      regForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const t = window.DRW_I18N ? window.DRW_I18N.t : (k) => k;
        if (regForm.password.value !== regForm.password2.value) {
          showErr(t('auth.mismatch'));
          return;
        }
        const btn = regForm.querySelector('button[type="submit"]');
        if (btn) btn.disabled = true;
        try {
          const data = await register(regForm.username.value.trim(), regForm.password.value);
          showOk(t('auth.ok_register'));
          setTimeout(() => redirectAfterAuth(data.user), 600);
        } catch (ex) {
          showErr(ex.message || 'Error');
        } finally {
          if (btn) btn.disabled = false;
        }
      });
    }
  });

  window.DRW_AUTH = { getToken, getUser, isLoggedIn, isAdmin, login, register, logout, api, setSession };
})();
