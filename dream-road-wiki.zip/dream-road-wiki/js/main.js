// Dream Road Wiki - Main JavaScript

document.addEventListener('DOMContentLoaded', () => {
  // Header scroll effect
  const header = document.querySelector('.header');
  if (header) {
    window.addEventListener('scroll', () => {
      header.classList.toggle('scrolled', window.scrollY > 50);
    });
  }

  // Mobile menu
  const mobileToggle = document.querySelector('.mobile-toggle');
  const navLinks = document.querySelector('.nav-links');
  if (mobileToggle && navLinks) {
    mobileToggle.addEventListener('click', () => {
      navLinks.classList.toggle('open');
    });
  }

  // Back to top
  const backToTop = document.querySelector('.back-to-top');
  if (backToTop) {
    window.addEventListener('scroll', () => {
      backToTop.classList.toggle('visible', window.scrollY > 400);
    });
    backToTop.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // FAQ accordion
  document.querySelectorAll('.faq-question').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.closest('.faq-item');
      const wasOpen = item.classList.contains('open');
      document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
      if (!wasOpen) item.classList.add('open');
    });
  });

  // Copy promo codes
  document.querySelectorAll('.copy-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const code = btn.dataset.code;
      try {
        await navigator.clipboard.writeText(code);
        btn.classList.add('copied');
        btn.innerHTML = `<svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"/></svg> Скопировано`;
        setTimeout(() => {
          btn.classList.remove('copied');
          btn.innerHTML = `<svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg> Копировать`;
        }, 2000);
      } catch (e) {
        alert('Не удалось скопировать: ' + code);
      }
    });
  });

  // Car filters & sort
  const carCards = document.querySelectorAll('.car-card');
  const filterBtns = document.querySelectorAll('.filter-btn');
  const sortSelect = document.querySelector('.sort-select');

  if (filterBtns.length && carCards.length) {
    filterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const filter = btn.dataset.filter;
        carCards.forEach(card => {
          if (filter === 'all' || card.dataset.category === filter) {
            card.classList.remove('hidden');
          } else {
            card.classList.add('hidden');
          }
        });
      });
    });
  }

  if (sortSelect && carCards.length) {
    sortSelect.addEventListener('change', () => {
      const container = document.querySelector('.cars-grid');
      if (!container) return;
      const cards = Array.from(carCards);
      const value = sortSelect.value;

      cards.sort((a, b) => {
        if (value === 'price-asc') return +a.dataset.price - +b.dataset.price;
        if (value === 'price-desc') return +b.dataset.price - +a.dataset.price;
        if (value === 'name') return a.dataset.name.localeCompare(b.dataset.name);
        return 0;
      });

      cards.forEach(c => container.appendChild(c));
    });
  }

  // Simple search (client-side highlight)
  const searchInput = document.querySelector('.search-box input');
  if (searchInput) {
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const q = searchInput.value.trim().toLowerCase();
        if (!q) return;
        // Redirect to cars page with query for demo
        if (window.location.pathname.includes('cars') || q.includes('машин') || q.includes('car')) {
          // stay or filter
        } else {
          window.location.href = 'cars.html?q=' + encodeURIComponent(q);
        }
      }
    });
  }

  // Animate elements on scroll
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animate-in');
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.card, .news-card, .guide-card, .promo-item, .stat-item').forEach(el => {
    el.style.opacity = '0';
    observer.observe(el);
  });

  // Auth nav state
  const authLink = document.getElementById('nav-auth-link');
  if (authLink && window.DRW_AUTH) {
    if (DRW_AUTH.isLoggedIn()) {
      const u = DRW_AUTH.getUser();
      if (u && u.role === 'admin') {
        authLink.href = 'admin/dashboard.html';
        authLink.textContent = (window.DRW_I18N && DRW_I18N.t('nav.admin')) || 'Админ';
        authLink.removeAttribute('data-i18n');
      } else {
        authLink.href = '#';
        authLink.textContent = (u && u.username) ? u.username : 'User';
        authLink.removeAttribute('data-i18n');
        authLink.title = 'Log out';
        authLink.addEventListener('click', (e) => {
          e.preventDefault();
          DRW_AUTH.logout();
        });
      }
    }
  }


  // Load live data from backend when available
  if (window.DRW_API) {
    DRW_API.isOnline().then(async (online) => {
      if (!online) return;
      const badge = document.getElementById('api-live-badge');
      if (badge) {
        badge.hidden = false;
        badge.textContent = 'API online';
      }
      // Optional: refresh cars grid from API if placeholder data-api-cars
      const grid = document.querySelector('[data-api-cars]');
      if (grid) {
        try {
          const cars = await DRW_API.getCars();
          if (Array.isArray(cars) && cars.length) {
            grid.dataset.apiLoaded = '1';
            // Keep static cards; only log for now / future full render
            console.info('[DRW] API cars:', cars.length);
          }
        } catch (e) { console.warn(e); }
      }
    });
  }

});
