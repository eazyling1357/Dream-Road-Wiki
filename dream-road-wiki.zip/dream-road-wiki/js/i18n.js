/**
 * Simple RU/EN i18n for Dream Road Wiki
 */
(function () {
  const KEY = 'drw_lang';
  const dict = {
    ru: {
      'nav.home': 'Главная',
      'nav.cars': 'Автомобили',
      'nav.news': 'Новости',
      'nav.guides': 'Гайды',
      'nav.map': 'Карта',
      'nav.faq': 'FAQ',
      'nav.auth': 'Вход',
      'nav.admin': 'Админ',
      'nav.logout': 'Выйти',
      'search.placeholder': 'Поиск по сайту...',
      'footer.rights': '© 2026 Dream Road Wiki',
      'footer.disclaimer': 'Данные могут отличаться от актуальных в игре.',
      'auth.title': 'Вход и регистрация',
      'auth.subtitle': 'Войдите, чтобы открыть админ-панель. Новый аккаунт — роль «пользователь».',
      'auth.tab_login': 'Вход',
      'auth.tab_register': 'Регистрация',
      'auth.username': 'Логин',
      'auth.password': 'Пароль',
      'auth.password2': 'Повтор пароля',
      'auth.submit_login': 'Войти',
      'auth.submit_register': 'Создать аккаунт',
      'auth.hint': 'Админ по умолчанию: admin / kassian89. Обычные пользователи не видят CRUD.',
      'auth.back': '← На главную',
      'auth.mismatch': 'Пароли не совпадают',
      'auth.ok_register': 'Аккаунт создан',
      'hero.title': 'Dream Road Wiki',
      'hero.lead': 'Каталог автомобилей, гайды, новости обновлений и полезные советы для игроков.',
    },
    en: {
      'nav.home': 'Home',
      'nav.cars': 'Cars',
      'nav.news': 'News',
      'nav.guides': 'Guides',
      'nav.map': 'Map',
      'nav.faq': 'FAQ',
      'nav.auth': 'Sign in',
      'nav.admin': 'Admin',
      'nav.logout': 'Log out',
      'search.placeholder': 'Search...',
      'footer.rights': '© 2026 Dream Road Wiki',
      'footer.disclaimer': 'Data may differ from the live game.',
      'auth.title': 'Sign in / Register',
      'auth.subtitle': 'Sign in to open the admin panel. New accounts get the user role.',
      'auth.tab_login': 'Sign in',
      'auth.tab_register': 'Register',
      'auth.username': 'Username',
      'auth.password': 'Password',
      'auth.password2': 'Confirm password',
      'auth.submit_login': 'Sign in',
      'auth.submit_register': 'Create account',
      'auth.hint': 'Default admin: admin / kassian89. Regular users cannot edit content.',
      'auth.back': '← Back to home',
      'auth.mismatch': 'Passwords do not match',
      'auth.ok_register': 'Account created',
      'hero.title': 'Dream Road Wiki',
      'hero.lead': 'Car catalog, guides, update news and tips for Dream Road Online players.',
    },
  };

  function getLang() {
    const saved = localStorage.getItem(KEY);
    if (saved === 'en' || saved === 'ru') return saved;
    return 'ru';
  }

  function setLang(lang) {
    if (lang !== 'en' && lang !== 'ru') lang = 'ru';
    localStorage.setItem(KEY, lang);
    document.documentElement.lang = lang;
    apply(lang);
    document.querySelectorAll('[data-set-lang]').forEach((btn) => {
      btn.classList.toggle('active', btn.getAttribute('data-set-lang') === lang);
    });
    window.dispatchEvent(new CustomEvent('drw:lang', { detail: { lang } }));
  }

  function t(key) {
    const lang = getLang();
    return (dict[lang] && dict[lang][key]) || (dict.ru && dict.ru[key]) || key;
  }

  function apply(lang) {
    lang = lang || getLang();
    document.querySelectorAll('[data-i18n]').forEach((el) => {
      const key = el.getAttribute('data-i18n');
      const val = t(key);
      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        if (el.hasAttribute('placeholder')) el.placeholder = val;
      } else {
        el.textContent = val;
      }
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
      el.placeholder = t(el.getAttribute('data-i18n-placeholder'));
    });
  }

  function initSwitcher() {
    document.querySelectorAll('[data-set-lang]').forEach((btn) => {
      btn.addEventListener('click', () => setLang(btn.getAttribute('data-set-lang')));
    });
  }

  window.DRW_I18N = { getLang, setLang, t, apply, initSwitcher, dict };

  document.addEventListener('DOMContentLoaded', () => {
    setLang(getLang());
    initSwitcher();
  });
})();
